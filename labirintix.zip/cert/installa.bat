certutil -addstore root www.iacosoft.com.public_key.cer
pause